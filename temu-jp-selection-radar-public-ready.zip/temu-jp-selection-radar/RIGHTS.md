# Rights and licensing status

No open-source license is granted for this repository at this time. Unless a separate written license applies, all rights are reserved by the relevant rights holder(s).

The code was created in an internship/business context. Before publishing this repository, the author should confirm in writing:

1. whether the internship agreement or employer policy assigns source-code ownership;
2. whether the Temu name may be used descriptively in the repository title and screenshots;
3. whether any internal requirements, thresholds, workflows, or business data are confidential;
4. whether a public portfolio copy is permitted.

If public open-source release is approved, a permissive license such as MIT may be appropriate for a small browser-extension portfolio project. Do not add that license until the person or company with authority has approved the release.
