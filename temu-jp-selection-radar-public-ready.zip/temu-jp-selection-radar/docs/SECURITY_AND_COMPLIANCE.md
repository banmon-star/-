# Security and compliance review

Review scope: source files supplied in `Temu日本本地仓选品雷达_V2.1.zip` and copied into `extension/`.

## Findings

### Secrets and personal data

- No API keys, access tokens, passwords, authorization headers, cookies, personal email addresses, phone numbers, or identity numbers were found.
- No analytics SDK, backend endpoint, `fetch`, `XMLHttpRequest`, or WebSocket transmission was found.
- Runtime results are stored in `chrome.storage.local` and can be deleted from the popup.
- No real CSV export, screenshot, account identifier, or proprietary dataset is included in this prepared repository.

### Browser permissions

| Permission | Observed purpose | Exposure |
| --- | --- | --- |
| `storage` | Save products, snapshots, settings, stores, and scan state locally | Local extension data persists until cleared |
| `activeTab` | Work with the active page after user interaction | Access is tied to the active tab/user action |
| `tabs` | Query the current tab, message it, and open candidate/store links | Broad tab metadata capability; review for possible future minimization |
| `https://www.temu.com/*`, `https://*.temu.com/*` | Run `content.js` on Temu pages | Page-reading capability across Temu subdomains |

The current code does not request cookies, browsing history, downloads, webRequest, clipboard, or all-sites access.

### Page automation and scraping-related behavior

- The scan is normally started by the user from the popup.
- It reads product/store information from loaded DOM text, attributes, links, meta tags, and embedded page text.
- It scrolls by roughly 86% of the viewport every 1.25 seconds, for at most 320 iterations, and stops earlier after repeated no-change/bottom observations.
- The “dig store” flow may programmatically click a seller/store element when a direct store URL cannot be extracted.
- A pending store scan may start automatically on the destination store page for up to 10 minutes after the user initiates that flow.
- The code does not bypass authentication, CAPTCHAs, paywalls, rate limits, or anti-bot controls.

These behaviors can still conflict with a website's current Terms of Use, robots policy, account rules, or local law. Before public distribution, check the current platform terms and obtain organizational/legal approval where needed. Do not market the extension as an official Temu product.

### Content and export safety

- Product titles and URLs are HTML-escaped before insertion into the popup's candidate list.
- Data written to CSV is escaped for commas, quotes, and newlines.
- Spreadsheet applications may interpret cells beginning with `=`, `+`, `-`, or `@` as formulas. Treat exported CSV as untrusted input and import it in a safe mode. A future hardening task is to neutralize formula-prefixed text fields.

### Accuracy and claims

- Candidate scores are deterministic heuristics in `popup.js`, not trained models.
- Historical metrics depend on repeated observations of page-displayed numbers.
- Displayed sales values can be rounded or differently defined across page types.
- No evidence in the repository validates lift, prediction accuracy, cost reduction, or profit improvement; portfolio claims should describe intended workflow benefits, not guaranteed results.

## Publication checklist

- [ ] Confirm source-code and business-IP ownership with the internship company.
- [ ] Confirm that public use of the company/project context is permitted.
- [ ] Re-check current Temu terms and browser-extension store policies.
- [ ] Replace demo media with synthetic or thoroughly redacted data.
- [ ] Test unpacked installation in clean Chrome and Edge profiles.
- [ ] Consider removing or narrowing the `tabs` permission after regression testing.
- [ ] Add CSV formula-injection hardening before distributing to untrusted users.
- [ ] Add an open-source license only after ownership/authorization is confirmed.

## Review boundary

This is a source review, not legal advice, a penetration test, or a live-platform compliance determination. The extension was not run against a logged-in Temu account during preparation.
