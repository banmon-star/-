# Screenshot and demo placeholders

Real screenshots were intentionally not included because none were supplied and live business/account data should not be invented or exposed.

Recommended portfolio media:

1. `01-extension-overview.png` — popup overview with synthetic counts and no account information.
2. `02-scan-in-progress.png` — scan status on a public/demo page; blur usernames, order details, IDs, and tracking parameters.
3. `03-top-candidates.png` — Top-5 rule score view using synthetic or authorized examples.
4. `04-csv-export.png` — sanitized spreadsheet preview; remove store IDs and commercially sensitive rows.
5. `demo.mp4` or an animated GIF — 20–40 seconds showing install, user-initiated scan, stop, and export.

Before committing media, verify that it contains no personal data, account identifiers, cookies, internal company information, private pricing, or third-party content you are not allowed to redistribute. The repository `.gitignore` excludes these media extensions by default; remove the relevant ignore rule only after review.
