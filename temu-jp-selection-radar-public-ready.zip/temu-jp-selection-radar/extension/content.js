(() => {
  if (window.__TEMU_LOCAL_SELECTOR_V21_LOADED__) return;
  window.__TEMU_LOCAL_SELECTOR_V21_LOADED__ = true;

  let autoRunning = false;
  let stopRequested = false;

  const STORAGE_KEY = "temuRadarProductsV2";
  const SNAPSHOT_KEY = "temuRadarSnapshotsV2";
  const STORE_KEY = "temuRadarStoresV2";
  const STATE_KEY = "temuRadarStateV2";
  const SETTINGS_KEY = "temuRadarSettingsV2";
  const PENDING_STORE_SCAN_KEY = "temuRadarPendingStoreScanV2";
  const LEGACY_KEY = "temuLocalSelectorProducts";

  const DEFAULT_SETTINGS = {
    excludeAds: true,
    localOnly: true,
    minPrice: 300,
    maxPrice: 0,
    minDaily: 0
  };

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function normalizeText(el) {
    return (el?.innerText || el?.textContent || "")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+/g, " ")
      .replace(/\n{2,}/g, "\n")
      .trim();
  }

  function parseCompactNumber(raw) {
    if (!raw) return null;
    const s = String(raw).replace(/,/g, "").replace(/\+/g, "").trim();
    const m = s.match(/^([0-9]*\.?[0-9]+)\s*(K|k|M|m|万)?$/);
    if (!m) return null;
    let n = Number(m[1]);
    if (/^[Kk]$/.test(m[2] || "")) n *= 1000;
    if (/^[Mm]$/.test(m[2] || "")) n *= 1000000;
    if (m[2] === "万") n *= 10000;
    return Math.round(n);
  }

  function isExactCount(raw) {
    if (!raw) return false;
    return /^[0-9][0-9,]*$/.test(String(raw).trim());
  }

  function parseListedDays(raw) {
    if (!raw) return null;
    const s = raw.replace(/\s/g, "");
    const nMatch = s.match(/([0-9]+(?:\.[0-9]+)?)/);
    const n = nMatch ? Number(nMatch[1]) : 1;
    if (/年|year/i.test(s)) return Math.round(n * 365);
    if (/月|month/i.test(s)) return Math.round(n * 30);
    if (/周|週|week/i.test(s)) return Math.round(n * 7);
    if (/日|天|day/i.test(s)) return Math.max(1, Math.round(n));
    if (/刚刚|刚上架|今日|today|just/i.test(s)) return 1;
    return null;
  }

  function productIdFromUrl(url) {
    const m = String(url || "").match(/-g-(\d+)\.html/i) || String(url || "").match(/[?&](?:goods_id|goodsId)=(\d+)/i);
    return m ? m[1] : null;
  }

  function decodeLooseUrl(raw) {
    if (!raw) return "";
    let s = String(raw)
      .replace(/\\u002F/gi, "/")
      .replace(/\\u0026/gi, "&")
      .replace(/\\\//g, "/")
      .replace(/&amp;/g, "&")
      .replace(/\\"/g, '"');
    try { s = decodeURIComponent(s); } catch (_) {}
    return s;
  }

  function storeIdFromUrl(url) {
    const s = decodeLooseUrl(url);
    const m = s.match(/-(\d{9,})-s\.html(?:$|[?#])/i)
      || s.match(/\/(?:store|stores)[\/-](\d{6,})/i)
      || s.match(/[?&](?:store_id|storeId|mall_id|mallId)=(\d{6,})/i);
    return m ? m[1] : "";
  }

  function looksLikeStoreUrl(url) {
    const s = decodeLooseUrl(url);
    return /-(\d{9,})-s\.html(?:$|[?#])/i.test(s)
      || /[?&](?:store_id|storeId|mall_id|mallId)=\d{6,}/i.test(s);
  }

  function normalizeStoreUrl(raw) {
    let s = decodeLooseUrl(raw).trim();
    if (!s) return "";
    if (s.startsWith("//")) s = location.protocol + s;
    else if (s.startsWith("/")) s = location.origin + s;
    try {
      const u = new URL(s, location.href);
      return u.origin + u.pathname + (u.search && /(?:store_id|storeId|mall_id|mallId)=/i.test(u.search) ? u.search : "");
    } catch (_) { return ""; }
  }

  function pageType() {
    const url = location.href;
    if (/-g-\d+\.html/i.test(url)) return "product";
    if (looksLikeStoreUrl(url)) return "store";
    return "list";
  }

  function collectElementSignals(root) {
    if (!root) return "";
    const chunks = [normalizeText(root)];
    const els = root.querySelectorAll?.("[aria-label],[title],[data-testid],[data-type],[data-label]") || [];
    for (const el of [...els].slice(0, 180)) {
      for (const name of ["aria-label", "title", "data-testid", "data-type", "data-label"]) {
        const v = el.getAttribute?.(name);
        if (v) chunks.push(v);
      }
    }
    return chunks.join(" | ");
  }

  function detectAd(card) {
    const signal = collectElementSignals(card);
    const patterns = [
      /(^|[\s|；;])广告(?=$|[\s|；;])/i,
      /\bSponsored\b/i,
      /\bSponsored\s*item\b/i,
      /スポンサー/i,
      /広告/i,
      /promoted\s*(item|product)?/i
    ];
    for (const p of patterns) {
      const m = signal.match(p);
      if (m) return {isAd: true, adReason: m[0]};
    }
    return {isAd: false, adReason: ""};
  }

  function findProductCard(anchor) {
    let node = anchor;
    let best = null;
    let bestScore = -1;
    for (let i = 0; i < 10 && node && node !== document.body; i++, node = node.parentElement) {
      const text = normalizeText(node);
      if (text.length < 15 || text.length > 2500) continue;
      let score = 0;
      if (/本地仓|Local\s*warehouse/i.test(text)) score += 3;
      if (/日销|周销|上架|跟卖|sold|已售/i.test(text)) score += 3;
      if (/\d[\d,]*\s*円/.test(text)) score += 3;
      if (node.querySelector?.("img")) score += 1;
      const productLinks = node.querySelectorAll?.('a[href*="-g-"]')?.length || 0;
      if (productLinks === 1) score += 2;
      if (productLinks > 6) score -= 3;
      if (score > bestScore) { bestScore = score; best = node; }
      if (score >= 8) break;
    }
    return bestScore >= 4 ? best : null;
  }

  function chooseTitle(card, anchor) {
    const candidates = [];
    const img = card.querySelector("img");
    [anchor.getAttribute("aria-label"), anchor.getAttribute("title"), img?.getAttribute("alt"), img?.getAttribute("title")]
      .forEach(x => x && candidates.push(x.trim()));
    normalizeText(card).split("\n").forEach(line => {
      const s = line.trim();
      if (s.length < 6 || s.length > 220) return;
      if (/^(日销|周销|上架|跟卖|本地仓|花火大促|秒杀|特价|仅剩|新品上市|畅销商品|评分|广告|Sponsored|\d+[,\.\dKkMm万+]*\s*已售)/i.test(s)) return;
      if (/^[\d,]+\s*円/.test(s)) return;
      candidates.push(s);
    });
    candidates.sort((a,b) => b.length - a.length);
    return candidates[0] || "";
  }

  function extractStoreNameFromText(text) {
    const patterns = [
      /(?:^|\n)\s*店铺名称\s*[:：]\s*([^\n|]{2,100})/i,
      /(?:^|\n)\s*(?:店舗名|ショップ名)\s*[:：]\s*([^\n|]{2,100})/i,
      /(?:Sold\s*by|Seller)\s*[:：]?\s*([^\n|()]{2,100})/i,
      /(?:販売元|販売者)\s*[:：]?\s*([^\n|()]{2,100})/i
    ];
    for (const p of patterns) {
      const m = text.match(p);
      if (m?.[1]) return m[1].trim().replace(/\s{2,}/g," ");
    }
    return "";
  }

  function extractInlineStoreCandidates() {
    const html = document.documentElement?.innerHTML || "";
    const out = [];
    const seen = new Set();
    const patterns = [
      /https?:\\?\/\\?\/[^"'<>\\\s]+?-\d{9,}-s\.html[^"'<>\\\s]*/gi,
      /\\?\/[^"'<>\\\s]{1,180}?-\d{9,}-s\.html[^"'<>\\\s]*/gi
    ];
    for (const p of patterns) {
      for (const m of html.matchAll(p)) {
        const u = normalizeStoreUrl(m[0]);
        if (u && looksLikeStoreUrl(u) && !seen.has(u)) { seen.add(u); out.push(u); }
        if (out.length >= 30) return out;
      }
    }
    return out;
  }

  function extractScriptStoreName() {
    const html = document.documentElement?.innerHTML || "";
    const patterns = [
      /["'](?:storeName|store_name|mallName|mall_name|sellerName|seller_name|shopName|shop_name)["']\s*:\s*["']([^"']{2,120})["']/i,
      /(?:storeName|mallName|sellerName|shopName)\\?"?\s*:\s*\\?"([^"\\]{2,120})/i
    ];
    for (const p of patterns) {
      const m = html.match(p);
      if (m?.[1]) {
        let v = m[1].replace(/\\u([0-9a-fA-F]{4})/g,(_,h)=>String.fromCharCode(parseInt(h,16))).replace(/\\"/g,'"').trim();
        if (v && v.length <= 120) return v;
      }
    }
    return "";
  }

  function extractStoreStats(text) {
    const pickNum = (patterns) => {
      for (const p of patterns) {
        const m = text.match(p);
        if (m?.[1]) return parseCompactNumber(m[1]);
      }
      return null;
    };
    const storeSales = pickNum([/(?:^|\n)\s*店铺销量\s*[:：]\s*([0-9.,]+\s*(?:K|k|M|m|万)?\+?)/i, /(?:店铺|店舗).{0,12}(?:累计销量|総販売数)\s*[:：]?\s*([0-9.,]+\s*(?:K|k|M|m|万)?\+?)/i]);
    const productCount = pickNum([/(?:^|\n)\s*店铺商品数\s*[:：]\s*([0-9.,]+)/i, /(?:商品数|アイテム数)\s*[:：]\s*([0-9.,]+)/i]);
    const followers = pickNum([/(?:^|\n)\s*店铺粉丝数\s*[:：]\s*([0-9.,]+\s*(?:K|k|M|m|万)?\+?)/i, /(?:followers?|フォロワー|粉丝)\s*[:：]?\s*([0-9.,]+\s*(?:K|k|M|m|万)?\+?)/i]);
    const ratingMatch = text.match(/(?:^|\n)\s*店铺评分(?:\/评论数)?\s*[:：]\s*([0-5](?:\.\d+)?)\s*(?:\/\s*([0-9,]+))?/i);
    const ageMatch = text.match(/(?:^|\n)\s*开店时间\s*[:：]\s*([^\n|]{1,30})/i);
    return {
      storeTotalSold: storeSales,
      storeProductCountReported: productCount,
      storeFollowers: followers,
      storeRating: ratingMatch ? Number(ratingMatch[1]) : null,
      storeReviewCount: ratingMatch?.[2] ? Number(ratingMatch[2].replace(/,/g,"")) : null,
      storeAgeText: ageMatch?.[1]?.trim() || ""
    };
  }

  function findStoreInfo(root = document) {
    const scope = root || document;
    const bodyText = normalizeText(scope === document ? document.body : scope);
    const nameFromText = extractStoreNameFromText(bodyText) || (scope === document ? extractScriptStoreName() : "");
    const anchors = [...scope.querySelectorAll?.('a[href]') || []];
    const candidates = anchors.filter(a => looksLikeStoreUrl(a.href || a.getAttribute("href") || ""));
    candidates.sort((a,b) => {
      const at = normalizeText(a), bt = normalizeText(b);
      const score = (t, el) =>
        (/sold by|seller|店铺|店舗|卖家|販売者|ショップ/i.test(t) ? 8 : 0) +
        (nameFromText && t.includes(nameFromText) ? 10 : 0) +
        (el.offsetParent !== null ? 2 : 0) + Math.min(t.length, 60)/60;
      return score(bt,b) - score(at,a);
    });

    let url = candidates[0] ? normalizeStoreUrl(candidates[0].href) : "";
    if (!url && scope === document) {
      const inline = extractInlineStoreCandidates();
      url = inline[0] || "";
    }
    const anchorName = candidates[0] ? normalizeText(candidates[0]).replace(/^(sold by|seller|店铺|店舗|卖家|販売者|ショップ)[:：]?\s*/i, "").trim() : "";
    const storeName = nameFromText || anchorName || "";
    return {
      storeId: storeIdFromUrl(url),
      storeName,
      storeUrl: url,
      ...extractStoreStats(bodyText)
    };
  }

  function findSellerClickable(storeName = "") {
    const els = [...document.querySelectorAll('a,button,[role="link"],[role="button"],[tabindex]')];
    const scored = [];
    for (const el of els) {
      const t = normalizeText(el);
      if (!t || t.length > 180) continue;
      let score = 0;
      if (/sold by|seller|店铺|店舗|卖家|販売者|ショップ/i.test(t)) score += 8;
      if (storeName && (t === storeName || t.includes(storeName))) score += 12;
      if (el.tagName === "A") score += 3;
      if (el.offsetParent !== null) score += 2;
      if (score >= 8) scored.push({el,score});
    }
    scored.sort((a,b)=>b.score-a.score);
    return scored[0]?.el || null;
  }


  function currentStoreInfo() {
    const found = findStoreInfo(document);
    if (pageType() !== "store") return found;
    const sid = storeIdFromUrl(location.href) || found.storeId || "";
    const h = [...document.querySelectorAll("h1,h2")].map(normalizeText).find(x => x && x.length <= 120) || "";
    const title = (document.title || "").replace(/\s*[-|]\s*Temu.*$/i, "").trim();
    return {
      ...found,
      storeId: sid,
      storeName: found.storeName || h || title || (sid ? `Store ${sid}` : ""),
      storeUrl: found.storeUrl || location.href.split("?")[0]
    };
  }

  function extractSellerRank(text) {
    const patterns = [
      /#\s*(\d+)\s*Best\s*Seller\s*from\s*this\s*seller/i,
      /#\s*(\d+)\s*best\s*seller/i,
      /(?:卖家|店铺|店舗).{0,12}(?:排名|排行)\s*#?\s*(\d+)/i,
      /#\s*(\d+).{0,12}(?:此卖家|该卖家|seller)/i
    ];
    for (const p of patterns) {
      const m = text.match(p);
      if (m) return Number(m[1]);
    }
    return null;
  }

  function parseCard(card, anchor, storeInfo = null) {
    const text = normalizeText(card);
    const href = anchor.href;
    const pid = productIdFromUrl(href);
    const pricesRaw = [...text.matchAll(/([0-9][0-9,]*)\s*円/g)]
      .map(m => Number(m[1].replace(/,/g,""))).filter(n => Number.isFinite(n));
    const currentPrice = pricesRaw.length ? Math.min(...pricesRaw) : null;
    const originalPrice = pricesRaw.length > 1 ? Math.max(...pricesRaw) : null;

    const dailyRaw = (text.match(/(?:日销|本日販売|today(?:'s)?\s*sales?)\s*[:：]?\s*([0-9.,]+\s*(?:K|k|M|m|万)?\+?)/i) || [])[1] || "";
    const weeklyRaw = (text.match(/(?:周销|週販|7日(?:销量|販売)|weekly\s*sales?)\s*[:：]?\s*([0-9.,]+\s*(?:K|k|M|m|万)?\+?)/i) || [])[1] || "";
    const soldRaw = (text.match(/([0-9.,]+\s*(?:K|k|M|m|万)?\+?)\s*(?:已售|sold)/i) || [])[1] || "";
    const listedRaw = (text.match(/(?:上架|listed)\s*[:：]?\s*([^|\n]{1,24})/i) || [])[1]?.trim() || "";
    const followRaw = (text.match(/(?:跟卖|followers?)\s*[:：]?\s*([0-9.,]+\s*(?:K|k|M|m|万)?\+?|查询)/i) || [])[1]?.trim() || "";

    const daily = parseCompactNumber(dailyRaw);
    const weekly = parseCompactNumber(weeklyRaw);
    const sold = parseCompactNumber(soldRaw);
    const follow = followRaw && !/查询/.test(followRaw) ? parseCompactNumber(followRaw) : null;
    const estimatedDaily = daily ?? (weekly != null ? Math.round((weekly / 7) * 10) / 10 : null);
    const img = card.querySelector("img");
    const ad = detectAd(card);

    const labelRx = /本地仓|Local warehouse|花火大促|秒杀|特价|新品上市|畅销商品|明星卖家|仅剩|评分最高|排名|Best Seller|ALMOST SOLD OUT|ONLY \d+ LEFT/i;
    const labels = [...new Set(text.split("\n").filter(x => labelRx.test(x)).slice(0, 16))].join("；");
    const sInfo = storeInfo || findStoreInfo(card);

    return {
      productId: pid || "",
      title: chooseTitle(card, anchor),
      url: href.split("?")[0],
      imageUrl: img?.currentSrc || img?.src || "",
      localWarehouse: /本地仓|Local\s*warehouse/i.test(text),
      currentPriceJpy: currentPrice,
      originalPriceJpy: originalPrice,
      allPriceCandidatesJpy: pricesRaw.join("|"),
      dailySales: daily,
      dailySalesRaw: dailyRaw,
      weeklySales: weekly,
      weeklySalesRaw: weeklyRaw,
      estimatedDailySales: estimatedDaily,
      totalSold: sold,
      totalSoldRaw: soldRaw,
      totalSoldExact: isExactCount(soldRaw),
      listingAgeText: listedRaw,
      listingDaysEstimate: parseListedDays(listedRaw),
      followerCount: follow,
      followerText: followRaw,
      isAd: ad.isAd,
      adReason: ad.adReason,
      labels,
      storeId: sInfo.storeId || "",
      storeName: sInfo.storeName || "",
      storeUrl: sInfo.storeUrl || "",
      sellerRank: extractSellerRank(text),
      capturedAt: new Date().toISOString(),
      pageUrl: location.href,
      pageType: pageType()
    };
  }

  async function getSettings() {
    const data = await chrome.storage.local.get([SETTINGS_KEY]);
    return {...DEFAULT_SETTINGS, ...(data[SETTINGS_KEY] || {})};
  }

  function mergeProduct(old, item) {
    const merged = {...old, ...item};
    for (const k of ["title","imageUrl","storeId","storeName","storeUrl","labels","adReason","totalSoldRaw","dailySalesRaw","weeklySalesRaw"]) {
      if (!item[k] && old?.[k]) merged[k] = old[k];
    }
    for (const k of ["currentPriceJpy","originalPriceJpy","dailySales","weeklySales","estimatedDailySales","totalSold","listingDaysEstimate","followerCount","sellerRank"]) {
      if (item[k] == null && old?.[k] != null) merged[k] = old[k];
    }
    merged.firstSeenAt = old?.firstSeenAt || item.capturedAt || new Date().toISOString();
    merged.lastSeenAt = item.capturedAt || new Date().toISOString();
    return merged;
  }

  function hoursBetween(a, b) {
    return Math.abs(new Date(a).getTime() - new Date(b).getTime()) / 3600000;
  }

  function makeSnapshot(item) {
    return {
      ts: item.capturedAt || new Date().toISOString(),
      totalSold: item.totalSold,
      totalSoldExact: !!item.totalSoldExact,
      totalSoldRaw: item.totalSoldRaw || "",
      dailySales: item.dailySales,
      weeklySales: item.weeklySales,
      price: item.currentPriceJpy
    };
  }

  function addSnapshot(history, item) {
    if (!item.productId) return;
    const arr = Array.isArray(history[item.productId]) ? history[item.productId] : [];
    const snap = makeSnapshot(item);
    const last = arr[arr.length - 1];
    const changed = !last || last.totalSold !== snap.totalSold || last.dailySales !== snap.dailySales || last.weeklySales !== snap.weeklySales || last.price !== snap.price;
    const enoughTime = !last || hoursBetween(last.ts, snap.ts) >= 6;
    if (changed || enoughTime) arr.push(snap);
    history[item.productId] = arr.slice(-40);
  }

  function rateFromHistory(arr, targetDays, minDays) {
    if (!Array.isArray(arr) || arr.length < 2) return null;
    const latest = [...arr].reverse().find(x => x.totalSold != null && x.totalSoldExact);
    if (!latest) return null;
    const latestTs = new Date(latest.ts).getTime();
    const candidates = arr.filter(x => x !== latest && x.totalSold != null && x.totalSoldExact && new Date(x.ts).getTime() < latestTs);
    if (!candidates.length) return null;
    let best = null;
    let bestDistance = Infinity;
    for (const x of candidates) {
      const days = (latestTs - new Date(x.ts).getTime()) / 86400000;
      if (days < minDays) continue;
      const dist = Math.abs(days - targetDays);
      if (dist < bestDistance) { bestDistance = dist; best = {x, days}; }
    }
    if (!best) return null;
    const delta = latest.totalSold - best.x.totalSold;
    if (delta < 0 || best.days <= 0) return null;
    return Math.round((delta / best.days) * 10) / 10;
  }

  function computeMetrics(item, arr) {
    const observed1d = rateFromHistory(arr, 1, 0.75);
    const avg3d = rateFromHistory(arr, 3, 2.25);
    const avg7d = rateFromHistory(arr, 7, 5.0);
    const avg14d = rateFromHistory(arr, 14, 10.0);
    const reported = item.dailySales != null ? item.dailySales : (item.weeklySales != null ? Math.round(item.weeklySales / 7 * 10) / 10 : null);
    const bestDaily = reported ?? observed1d ?? avg3d ?? null;
    const trend3v7 = avg3d != null && avg7d > 0 ? Math.round(((avg3d / avg7d) - 1) * 1000) / 10 : null;
    const burst = avg3d != null && avg14d > 0 ? Math.round((avg3d / avg14d) * 100) / 100 : null;
    let confidence = "不足";
    if (item.dailySales != null) confidence = "页面日销";
    else if (observed1d != null) confidence = "历史差值-高";
    else if (avg3d != null) confidence = "历史差值-中";
    else if (item.weeklySales != null) confidence = "周销折算";
    return {observed1d, avg3d, avg7d, avg14d, bestDaily, trend3v7, burst, confidence};
  }

  async function persistItems(items, meta = {}) {
    if (!items.length) return {added:0,total:0};
    const data = await chrome.storage.local.get([STORAGE_KEY, SNAPSHOT_KEY, STORE_KEY]);
    const existing = Array.isArray(data[STORAGE_KEY]) ? data[STORAGE_KEY] : [];
    const history = data[SNAPSHOT_KEY] && typeof data[SNAPSHOT_KEY] === "object" ? data[SNAPSHOT_KEY] : {};
    const stores = data[STORE_KEY] && typeof data[STORE_KEY] === "object" ? data[STORE_KEY] : {};
    const merged = new Map(existing.map(x => [x.productId || x.url?.split("?")[0], x]));

    for (const item of items) {
      const key = item.productId || item.url?.split("?")[0];
      if (!key) continue;
      addSnapshot(history, item);
      const m = mergeProduct(merged.get(key), item);
      const metrics = computeMetrics(m, history[item.productId] || []);
      Object.assign(m, metrics);
      merged.set(key, m);
      if (m.storeId || m.storeUrl) {
        const sk = m.storeId || m.storeUrl;
        stores[sk] = {
          ...(stores[sk] || {}),
          storeId: m.storeId || stores[sk]?.storeId || "",
          storeName: m.storeName || stores[sk]?.storeName || "",
          storeUrl: m.storeUrl || stores[sk]?.storeUrl || "",
          lastSeenAt: m.capturedAt,
          sourceProductId: meta.sourceProductId || stores[sk]?.sourceProductId || "",
          storeTotalSold: m.storeTotalSold ?? stores[sk]?.storeTotalSold ?? null,
          storeProductCountReported: m.storeProductCountReported ?? stores[sk]?.storeProductCountReported ?? null,
          storeFollowers: m.storeFollowers ?? stores[sk]?.storeFollowers ?? null,
          storeRating: m.storeRating ?? stores[sk]?.storeRating ?? null,
          storeReviewCount: m.storeReviewCount ?? stores[sk]?.storeReviewCount ?? null,
          storeAgeText: m.storeAgeText || stores[sk]?.storeAgeText || ""
        };
      }
    }

    const result = [...merged.values()];
    await chrome.storage.local.set({[STORAGE_KEY]: result, [SNAPSHOT_KEY]: history, [STORE_KEY]: stores});
    return {added:items.length,total:result.length};
  }

  async function migrateLegacyOnce() {
    const d = await chrome.storage.local.get([STORAGE_KEY, LEGACY_KEY]);
    if (Array.isArray(d[STORAGE_KEY]) && d[STORAGE_KEY].length) return;
    const legacy = Array.isArray(d[LEGACY_KEY]) ? d[LEGACY_KEY] : [];
    if (!legacy.length) return;
    const now = new Date().toISOString();
    const converted = legacy.map(x => ({
      ...x,
      isAd: /(^|\s)广告|Sponsored|スポンサー|広告/i.test(x.title || ""),
      adReason: /广告/.test(x.title || "") ? "广告" : "",
      totalSoldExact: false,
      firstSeenAt: x.capturedAt || now,
      lastSeenAt: x.capturedAt || now,
      capturedAt: x.capturedAt || now
    }));
    await persistItems(converted);
  }

  async function scanVisible(options = {}) {
    await migrateLegacyOnce();
    const settings = await getSettings();
    const pType = pageType();
    const pageStore = pType === "store" ? currentStoreInfo() : null;
    const anchors = [...document.querySelectorAll('a[href]')].filter(a => {
      const h = a.href || "";
      return /-g-\d+\.html/i.test(h) || /goods(?:_id|Id)?=/i.test(h);
    });

    const byKey = new Map();
    let skippedAds = 0;
    for (const a of anchors) {
      const card = findProductCard(a);
      if (!card) continue;
      const item = parseCard(card, a, pageStore);
      const key = item.productId || item.url.split("?")[0];
      if (!key || !item.currentPriceJpy) continue;
      if ((settings.excludeAds || options.excludeAds) && item.isAd) { skippedAds++; continue; }
      if (!byKey.has(key)) byKey.set(key, item);
      else {
        const old = byKey.get(key);
        if ((item.title?.length || 0) > (old.title?.length || 0)) byKey.set(key, item);
      }
    }

    const res = await persistItems([...byKey.values()]);
    return {found: byKey.size, skippedAds, total: res.total, pageType:pType, store:pageStore};
  }

  function pickDetailTitle() {
    const h1s = [...document.querySelectorAll("h1")].map(normalizeText).filter(x => x.length >= 5 && x.length <= 300);
    if (h1s.length) return h1s.sort((a,b)=>b.length-a.length)[0];
    return (document.title || "").replace(/\s*[-|]\s*Temu.*$/i, "").trim();
  }

  async function captureCurrentProductDetail() {
    if (pageType() !== "product") return {ok:false, error:"当前不是商品详情页"};
    const text = normalizeText(document.body);
    const pid = productIdFromUrl(location.href);
    const store = findStoreInfo(document);
    const helperSold = (text.match(/(?:^|\n)\s*销量\s*[:：]\s*([0-9][0-9,.]*\s*(?:K|k|M|m|万)?\+?)\s*(?:件)?(?=\n|$)/i) || [])[1] || "";
    const nativeSoldAfter = (text.match(/(?:已售|sold)\s*[:：]?\s*([0-9.,]+\s*(?:K|k|M|m|万)?\+?)/i) || [])[1] || "";
    const nativeSoldBefore = (text.match(/([0-9.,]+\s*(?:K|k|M|m|万)?\+?)\s*(?:件)?\s*(?:已售|sold)/i) || [])[1] || "";
    const soldRaw = helperSold || nativeSoldAfter || nativeSoldBefore;
    const dailyRaw = (text.match(/(?:日销|本日販売|today(?:'s)?\s*sales?)\s*[:：]?\s*([0-9.,]+\s*(?:K|k|M|m|万)?\+?)/i) || [])[1] || "";
    const weeklyRaw = (text.match(/(?:周销|週販|7日(?:销量|販売)|weekly\s*sales?)\s*[:：]?\s*([0-9.,]+\s*(?:K|k|M|m|万)?\+?)/i) || [])[1] || "";
    const metaPriceRaw = document.querySelector('meta[property="product:price:amount"]')?.content
      || document.querySelector('meta[itemprop="price"]')?.content
      || document.querySelector('[itemprop="price"]')?.getAttribute?.('content')
      || "";
    const metaPrice = Number(String(metaPriceRaw).replace(/,/g, ""));
    const priceCandidates = Number.isFinite(metaPrice) && metaPrice > 0 ? [metaPrice] : [];
    const price = priceCandidates.length ? priceCandidates[0] : null;
    const item = {
      productId: pid || "",
      title: pickDetailTitle(),
      url: location.href.split("?")[0],
      imageUrl: document.querySelector('meta[property="og:image"]')?.content || document.querySelector("img")?.currentSrc || "",
      localWarehouse: /本地仓|Local\s*warehouse/i.test(text),
      currentPriceJpy: price,
      originalPriceJpy: null,
      allPriceCandidatesJpy: priceCandidates.join("|"),
      dailySales: parseCompactNumber(dailyRaw),
      dailySalesRaw: dailyRaw,
      weeklySales: parseCompactNumber(weeklyRaw),
      weeklySalesRaw: weeklyRaw,
      estimatedDailySales: parseCompactNumber(dailyRaw) ?? (parseCompactNumber(weeklyRaw) != null ? Math.round(parseCompactNumber(weeklyRaw)/7*10)/10 : null),
      totalSold: parseCompactNumber(soldRaw),
      totalSoldRaw: soldRaw,
      totalSoldExact: isExactCount(soldRaw),
      isAd: false,
      adReason: "",
      labels: "",
      storeId: store.storeId,
      storeName: store.storeName,
      storeUrl: store.storeUrl,
      storeTotalSold: store.storeTotalSold ?? null,
      storeProductCountReported: store.storeProductCountReported ?? null,
      storeFollowers: store.storeFollowers ?? null,
      storeRating: store.storeRating ?? null,
      storeReviewCount: store.storeReviewCount ?? null,
      storeAgeText: store.storeAgeText || "",
      sellerRank: extractSellerRank(text),
      capturedAt: new Date().toISOString(),
      pageUrl: location.href,
      pageType: "product"
    };
    await persistItems([item], {sourceProductId:pid});
    return {ok:true, product:item, store};
  }

  async function digCurrentStore() {
    if (pageType() !== "product") return {ok:false, error:"请先打开具体商品详情页"};
    const detail = await captureCurrentProductDetail();
    if (!detail?.ok) return detail;
    const store = detail.store || findStoreInfo(document);
    const pending = {
      storeUrl: store.storeUrl || "",
      storeName: store.storeName || "",
      storeId: store.storeId || "",
      createdAt: Date.now(),
      sourceProductId: detail.product?.productId || ""
    };
    await chrome.storage.local.set({[PENDING_STORE_SCAN_KEY]: pending});
    if (store.storeUrl) return {ok:true, action:"openUrl", store, product:detail.product};

    const clickable = findSellerClickable(store.storeName);
    if (clickable) {
      try {
        clickable.scrollIntoView({block:"center", behavior:"smooth"});
        await sleep(250);
        clickable.click();
        return {ok:true, action:"clicked", store, product:detail.product};
      } catch (_) {}
    }
    return {ok:false, error:`已识别商品 ${detail.product?.productId || ""}${store.storeName ? `，店铺名：${store.storeName}` : ""}，但暂未拿到可跳转的店铺链接。` , store, product:detail.product};
  }

  async function setState(state) {
    await chrome.storage.local.set({[STATE_KEY]: {...state, updatedAt:new Date().toISOString()}});
  }

  async function autoScan() {
    if (autoRunning) return;
    autoRunning = true;
    stopRequested = false;
    const pType = pageType();
    await setState({running:true, message:pType === "store" ? "正在扫描店铺商品" : "自动采集中", pageType:pType});
    let noNewRounds = 0;
    let lastTotal = -1;
    let bottomRounds = 0;

    try {
      for (let i = 0; i < 320 && !stopRequested; i++) {
        const res = await scanVisible();
        if (res.total === lastTotal) noNewRounds++; else noNewRounds = 0;
        lastTotal = res.total;
        const nearBottom = (window.scrollY + window.innerHeight) >= (document.documentElement.scrollHeight - 240);
        if (nearBottom) bottomRounds++; else bottomRounds = 0;
        await setState({running:true, message:`${pType === "store" ? "店铺扫描" : "自动采集"}：累计 ${res.total} 件，已跳过广告 ${res.skippedAds} 件`, pageType:pType});
        if (noNewRounds >= 10 && bottomRounds >= 4) break;
        window.scrollBy({top: Math.max(650, Math.floor(window.innerHeight * 0.86)), behavior:"smooth"});
        await sleep(1250);
      }
      await scanVisible();
    } finally {
      autoRunning = false;
      await setState({running:false, message: stopRequested ? "已手动停止" : (pType === "store" ? "店铺扫描完成" : "自动采集完成"), pageType:pType});
      if (pType === "store") await chrome.storage.local.remove(PENDING_STORE_SCAN_KEY);
    }
  }

  async function getPageContext() {
    const type = pageType();
    const store = findStoreInfo(document);
    let product = null;
    if (type === "product") {
      const r = await captureCurrentProductDetail();
      product = r.product || null;
    }
    return {type, store, product, url:location.href};
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
      if (msg?.type === "scan") {
        const res = await scanVisible();
        sendResponse({ok:true, ...res});
      } else if (msg?.type === "start") {
        autoScan();
        sendResponse({ok:true});
      } else if (msg?.type === "stop") {
        stopRequested = true;
        sendResponse({ok:true});
      } else if (msg?.type === "pageContext") {
        sendResponse({ok:true, ...(await getPageContext())});
      } else if (msg?.type === "captureDetail") {
        sendResponse(await captureCurrentProductDetail());
      } else if (msg?.type === "digStore") {
        sendResponse(await digCurrentStore());
      } else {
        sendResponse({ok:false});
      }
    })().catch(err => sendResponse({ok:false,error:String(err?.message || err)}));
    return true;
  });

  (async () => {
    await migrateLegacyOnce();
    const p = await chrome.storage.local.get([PENDING_STORE_SCAN_KEY]);
    const pending = p[PENDING_STORE_SCAN_KEY];
    if (pending && Date.now() - Number(pending.createdAt || 0) < 10 * 60 * 1000) {
      const targetId = storeIdFromUrl(pending.storeUrl || "");
      const hereId = storeIdFromUrl(location.href);
      const bodyText = normalizeText(document.body);
      const looksStorePage = pageType() === "store" || looksLikeStoreUrl(location.href)
        || (!!pending.storeName && bodyText.includes(pending.storeName) && /关注|フォロー|Follow/i.test(bodyText));
      if (looksStorePage && (!targetId || !hereId || targetId === hereId)) {
        await sleep(1800);
        autoScan();
      }
    }
  })();
})();
