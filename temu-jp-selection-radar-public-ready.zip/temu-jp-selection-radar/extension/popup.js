const PRODUCT_KEY = "temuRadarProductsV2";
const SNAPSHOT_KEY = "temuRadarSnapshotsV2";
const STORE_KEY = "temuRadarStoresV2";
const STATE_KEY = "temuRadarStateV2";
const SETTINGS_KEY = "temuRadarSettingsV2";
const PENDING_STORE_SCAN_KEY = "temuRadarPendingStoreScanV2";

const DEFAULT_SETTINGS = {excludeAds:true, localOnly:true, minPrice:300, maxPrice:0, minDaily:0};
const $ = id => document.getElementById(id);
const setMessage = s => $("message").textContent = s;

async function currentTab() {
  const tabs = await chrome.tabs.query({active:true, currentWindow:true});
  return tabs[0];
}

async function send(type) {
  const tab = await currentTab();
  if (!tab?.id || !/^https:\/\/([^/]+\.)?temu\.com\//i.test(tab.url || "")) {
    setMessage("请先打开 Temu 日本站页面。");
    return null;
  }
  try {
    return await chrome.tabs.sendMessage(tab.id, {type});
  } catch (e) {
    setMessage("页面脚本尚未加载。请刷新 Temu 页面后重试。");
    return null;
  }
}

function n(v, digits=0) {
  if (v == null || Number.isNaN(Number(v))) return "—";
  return Number(v).toLocaleString("zh-CN", {maximumFractionDigits:digits});
}

function pct(v) {
  if (v == null || Number.isNaN(Number(v))) return "—";
  return `${Number(v) >= 0 ? "+" : ""}${Number(v).toFixed(1)}%`;
}

function filteredProducts(rows, settings) {
  return rows.filter(x => {
    if (settings.excludeAds && x.isAd) return false;
    if (settings.localOnly && !x.localWarehouse) return false;
    const p = Number(x.currentPriceJpy || 0);
    if (settings.minPrice && p < settings.minPrice) return false;
    if (settings.maxPrice && p > settings.maxPrice) return false;
    if (settings.minDaily && Number(x.bestDaily || x.dailySales || 0) < settings.minDaily) return false;
    return true;
  });
}

function scoreProduct(x) {
  const daily = Number(x.bestDaily || 0);
  const trend = Number(x.trend3v7 || 0);
  const burst = Number(x.burst || 0);
  const sold = Number(x.totalSold || 0);
  let score = Math.min(daily, 150) / 150 * 50;
  score += Math.max(Math.min(trend, 150), -50) / 150 * 20;
  score += Math.min(Math.max(burst - 1, 0), 3) / 3 * 15;
  score += Math.min(sold, 5000) / 5000 * 10;
  if (x.sellerRank && x.sellerRank <= 3) score += 5;
  if (x.isAd) score -= 100;
  return Math.round(score * 10) / 10;
}

function aggregateStores(products, storeMap) {
  const groups = {};
  for (const p of products) {
    const key = p.storeId || p.storeUrl;
    if (!key) continue;
    (groups[key] ||= []).push(p);
  }
  const out = [];
  for (const [key, rows] of Object.entries(groups)) {
    const valid = rows.filter(x => !x.isAd);
    const dailies = valid.map(x => Number(x.bestDaily || 0)).filter(x => x > 0).sort((a,b)=>a-b);
    const med = dailies.length ? dailies[Math.floor(dailies.length/2)] : 0;
    const totalDaily = dailies.reduce((a,b)=>a+b,0);
    const sorted = [...valid].sort((a,b)=>Number(b.bestDaily||0)-Number(a.bestDaily||0));
    const top3Daily = sorted.slice(0,3).reduce((s,x)=>s+Number(x.bestDaily||0),0);
    const explosive = valid.filter(x => Number(x.trend3v7||0) >= 30 || Number(x.burst||0) >= 1.5).length;
    const active20 = valid.filter(x => Number(x.bestDaily||0) >= 20).length;
    const active50 = valid.filter(x => Number(x.bestDaily||0) >= 50).length;
    const density = valid.length ? active20 / valid.length : 0;
    const concentration = totalDaily > 0 ? top3Daily / totalDaily : 1;
    const score = Math.round(Math.min(100,
      Math.min(med,50)/50*25 +
      Math.min(density,0.5)/0.5*30 +
      Math.min(explosive,5)/5*20 +
      Math.min(valid.length,40)/40*10 +
      Math.max(0,1-concentration)*15
    ));
    const meta = storeMap[key] || {};
    out.push({
      storeKey:key, storeId:meta.storeId || rows[0].storeId || "", storeName:meta.storeName || rows[0].storeName || "",
      storeUrl:meta.storeUrl || rows[0].storeUrl || "", productCount:valid.length, daily20:active20, daily50:active50,
      medianDaily:med, explosiveCount:explosive, burstDensity:density, top3Concentration:concentration, storeScore:score,
      lastSeenAt:meta.lastSeenAt || ""
    });
  }
  return out.sort((a,b)=>b.storeScore-a.storeScore);
}

async function getAllData() {
  const d = await chrome.storage.local.get([PRODUCT_KEY, SNAPSHOT_KEY, STORE_KEY, STATE_KEY, SETTINGS_KEY]);
  return {
    products:Array.isArray(d[PRODUCT_KEY]) ? d[PRODUCT_KEY] : [],
    snapshots:d[SNAPSHOT_KEY] || {}, stores:d[STORE_KEY] || {}, state:d[STATE_KEY] || {},
    settings:{...DEFAULT_SETTINGS, ...(d[SETTINGS_KEY] || {})}
  };
}

async function saveSettings() {
  const settings = {
    excludeAds:$("excludeAds").checked,
    localOnly:$("localOnly").checked,
    minPrice:Number($("minPrice").value || 0),
    maxPrice:Number($("maxPrice").value || 0),
    minDaily:Number($("minDaily").value || 0)
  };
  await chrome.storage.local.set({[SETTINGS_KEY]:settings});
  refresh();
}

async function refresh() {
  const d = await getAllData();
  const rows = d.products;
  const filtered = filteredProducts(rows, d.settings);
  const nonAds = rows.filter(x=>!x.isAd).length;
  const storeRows = aggregateStores(filtered, d.stores);
  $("count").textContent = rows.length;
  $("nonAdCount").textContent = nonAds;
  $("storeCount").textContent = storeRows.length;
  $("hotCount").textContent = filtered.filter(x=>Number(x.bestDaily||0)>=20 || Number(x.trend3v7||0)>=30 || Number(x.burst||0)>=1.5).length;
  const st = d.state || {};
  $("runState").textContent = st.running ? "采集中" : "空闲";
  $("runState").className = `pill ${st.running ? "running" : ""}`;
  if (st.message) setMessage(st.message);

  $("excludeAds").checked = d.settings.excludeAds;
  $("localOnly").checked = d.settings.localOnly;
  $("minPrice").value = d.settings.minPrice || 0;
  $("maxPrice").value = d.settings.maxPrice || 0;
  $("minDaily").value = d.settings.minDaily || 0;

  const top = [...filtered].map(x=>({...x, radarScore:scoreProduct(x)})).sort((a,b)=>b.radarScore-a.radarScore).slice(0,5);
  $("topList").innerHTML = top.length ? top.map((x,i)=>`
    <button class="candidate" data-url="${escapeHtml(x.url || "")}">
      <span class="rank">${i+1}</span>
      <span class="ct"><b>${escapeHtml((x.title||"未命名").slice(0,48))}</b><small>日销 ${n(x.bestDaily,1)} · 3日 ${n(x.avg3d,1)} · 趋势 ${pct(x.trend3v7)} · 分 ${n(x.radarScore,1)}</small></span>
    </button>`).join("") : `<div class="empty">暂无足够数据。连续几天扫描后会自动出现趋势。</div>`;
  document.querySelectorAll(".candidate").forEach(el=>el.addEventListener("click",()=>chrome.tabs.create({url:el.dataset.url})));
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}

function csvEscape(v) {
  if (v == null) return "";
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g,'""')}"` : s;
}

function downloadCsv(name, headers, rows) {
  const lines = [headers.map(x=>csvEscape(x[1])).join(",")];
  for (const row of rows) lines.push(headers.map(([k])=>csvEscape(row[k])).join(","));
  const blob = new Blob(["\ufeff" + lines.join("\r\n")], {type:"text/csv;charset=utf-8;"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1500);
}

async function exportProducts() {
  const d = await getAllData();
  const rows = filteredProducts(d.products, d.settings).map(x=>({...x, radarScore:scoreProduct(x)}));
  if (!rows.length) return setMessage("没有符合当前条件的商品。");
  const headers = [
    ["productId","商品ID"],["title","商品名称"],["url","商品链接"],["imageUrl","图片链接"],
    ["storeId","店铺ID"],["storeName","店铺名称"],["storeUrl","店铺链接"],["sellerRank","店内排名"],
    ["localWarehouse","本地仓"],["isAd","广告"],["adReason","广告识别依据"],
    ["currentPriceJpy","当前价_JPY"],["originalPriceJpy","原价_JPY"],
    ["dailySales","页面日销"],["weeklySales","页面周销"],["observed1d","历史1日日销"],["avg3d","3日日均"],["avg7d","7日日均"],["avg14d","14日日均"],
    ["bestDaily","当前参考日销"],["trend3v7","3日对7日趋势_%"],["burst","爆发系数_3日对14日"],["confidence","日销置信度"],
    ["totalSold","累计已售"],["totalSoldRaw","累计销量原文"],["totalSoldExact","累计销量精确值"],
    ["listingAgeText","上架时间文本"],["listingDaysEstimate","上架天数估算"],["labels","活动标签"],["radarScore","选品雷达分"],
    ["firstSeenAt","首次观察"],["lastSeenAt","最近观察"],["pageUrl","来源页"]
  ];
  const stamp = new Date().toISOString().slice(0,10);
  downloadCsv(`Temu日本选品雷达_商品_${stamp}.csv`, headers, rows.sort((a,b)=>b.radarScore-a.radarScore));
  setMessage(`已导出 ${rows.length} 个非广告候选商品。`);
}

async function exportStores() {
  const d = await getAllData();
  const rows = aggregateStores(filteredProducts(d.products,d.settings), d.stores);
  if (!rows.length) return setMessage("还没有店铺数据。请从商品详情页执行“一键挖店铺”。");
  const headers = [
    ["storeId","店铺ID"],["storeName","店铺名称"],["storeUrl","店铺链接"],["productCount","已扫描有效商品数"],
    ["daily20","日销20+商品数"],["daily50","日销50+商品数"],["medianDaily","店铺日销中位数"],["explosiveCount","高增长商品数"],
    ["burstDensity","爆款密度"],["top3Concentration","TOP3日销集中度"],["storeScore","店铺评分"],["lastSeenAt","最近观察"]
  ];
  const stamp = new Date().toISOString().slice(0,10);
  downloadCsv(`Temu日本选品雷达_店铺_${stamp}.csv`, headers, rows);
  setMessage(`已导出 ${rows.length} 个店铺。`);
}

async function openAndScanStore() {
  setMessage("正在补全商品并识别店铺...");
  const r = await send("digStore");
  if (!r?.ok) {
    setMessage(r?.error || "店铺识别失败。请刷新商品页后再试。");
    return;
  }
  const name = r.store?.storeName || r.store?.storeId || "当前店铺";
  if (r.action === "openUrl" && r.store?.storeUrl) {
    setMessage(`已识别 ${name}，正在进入店铺并自动扫描...`);
    await chrome.tabs.create({url:r.store.storeUrl, active:true});
  } else if (r.action === "clicked") {
    setMessage(`已识别 ${name}，正在通过页面店铺入口进入；进入后会自动扫描。`);
  } else {
    setMessage(`已补全商品，但 ${name} 暂未获得可跳转链接。`);
  }
  refresh();
}

$("scan").addEventListener("click", async () => {
  await saveSettings();
  setMessage("正在扫描当前页面，广告将按设置过滤...");
  const r = await send("scan");
  if (r?.ok) setMessage(`识别 ${r.found} 件；跳过广告 ${r.skippedAds || 0} 件；累计 ${r.total} 件。`);
  refresh();
});
$("start").addEventListener("click", async () => { await saveSettings(); await send("start"); setMessage("已开始自动向下滚动采集。"); refresh(); });
$("stop").addEventListener("click", async () => { await send("stop"); setMessage("正在停止..."); setTimeout(refresh,700); });
$("storeScan").addEventListener("click", openAndScanStore);
$("exportProducts").addEventListener("click", exportProducts);
$("exportStores").addEventListener("click", exportStores);
$("clearProducts").addEventListener("click", async()=>{
  if (!confirm("清空商品列表，但保留历史销量快照和店铺记录？")) return;
  await chrome.storage.local.set({[PRODUCT_KEY]:[], [STATE_KEY]:{running:false,message:"商品列表已清空，历史快照仍保留"}});
  refresh();
});
$("clearAll").addEventListener("click", async()=>{
  if (!confirm("确认清空商品、历史销量、店铺数据？此操作不可恢复。")) return;
  await chrome.storage.local.remove([PRODUCT_KEY,SNAPSHOT_KEY,STORE_KEY,STATE_KEY,PENDING_STORE_SCAN_KEY]);
  setMessage("全部雷达数据已清空。"); refresh();
});
["excludeAds","localOnly","minPrice","maxPrice","minDaily"].forEach(id=>$(id).addEventListener("change",saveSettings));
chrome.storage.onChanged.addListener(()=>refresh());
refresh();
setInterval(refresh,1800);
